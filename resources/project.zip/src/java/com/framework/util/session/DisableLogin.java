package com.framework.util.session;

/**
 *
 * @author maycon
 */
public interface DisableLogin {

}
